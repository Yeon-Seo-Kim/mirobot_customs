#!/usr/bin/env python3

import rospy
from mirobot_controller.srv import MoveJoints, MoveJointsRequest

def move_mirobot_joints():
    rospy.init_node('move_joints_client')
    rospy.wait_for_service('/move_joints')

    try:
        move_joints = rospy.ServiceProxy('/move_joints', MoveJoints)
        req = MoveJointsRequest()
        req.joint_names = ['joint1', 'joint2', 'joint3', 'joint4', 'joint5', 'joint6']
        req.joint_positions = [-0.0, -0.0, 0.0, -0.0, -0.0, -0.0]

        resp = move_joints(req)
        if resp.success:
            rospy.loginfo(f"Joint movement successful: {resp.message}")
        else:
            rospy.logerr(f"Joint movement failed: {resp.message}")

    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

if __name__ == '__main__':
    try:
        move_mirobot_joints()
    except rospy.ROSInterruptException:
        pass