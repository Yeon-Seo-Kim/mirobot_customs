#include "ros/ros.h"
#include "sensor_msgs/JointState.h"
#include "mirobot_controller/MoveJoints.h" // 우리가 만든 서비스 헤더

#include <string>
#include <vector>
#include <map>
#include <utility>
#include <sstream>
#include <iomanip>

class JointController {
public:
    JointController() {
        ros::NodeHandle nh;
        // 이 퍼블리셔가 Gazebo나 Rviz의 'joint_state_controller'가 구독하는 토픽으로 메시지를 보냅니다.
        joint_pub_ = nh.advertise<sensor_msgs::JointState>("/foward_joint_states", 10);
        
        // "move_joints" 라는 이름의 서비스를 제공합니다. IK 노드가 이 서비스를 호출합니다.
        move_joints_service_ = nh.advertiseService("move_joints", &JointController::handleMoveJoints, this);
        ROS_INFO("JointController: MoveJoints Service is Ready.");
    }

    bool handleMoveJoints(mirobot_controller::MoveJoints::Request &req,
                          mirobot_controller::MoveJoints::Response &res)
    {
        ROS_INFO("JointController: Received request for %zu joints.", req.joint_names.size());

        if (req.joint_names.size() != req.joint_positions.size()) {
            res.success = false;
            res.message = "Error: Mismatch in joint_names and joint_positions array lengths.";
            ROS_ERROR("JointController: %s", res.message.c_str());
            return true; 
        }

        // 사용자가 제공한 URDF 데이터 기반의 정확한 관절 가동 범위 (라디안)
        std::map<std::string, std::pair<double, double>> joint_limits = {
            {"joint1", {-1.7453, 2.7925}},
            {"joint2", {-0.5235, 1.2217}},
            {"joint3", {-2.9671, 1.0472}},
            {"joint4", {-6.1086, 6.1086}},
            {"joint5", {-3.5779, 0.6283}},
            {"joint6", {-6.2832, 6.2832}},
        };

        // 요청된 각 관절의 위치가 가동 범위를 벗어나는지 검사
        for (size_t i = 0; i < req.joint_names.size(); ++i) {
            const auto& joint_name = req.joint_names[i];
            double target_position = req.joint_positions[i];

            if (joint_limits.find(joint_name) == joint_limits.end()) {
                res.success = false;
                res.message = "Error: Unknown joint name '" + joint_name + "'.";
                ROS_ERROR("JointController: %s", res.message.c_str());
                return true;
            }

            double lower = joint_limits[joint_name].first;
            double upper = joint_limits[joint_name].second;

            if (target_position < lower || target_position > upper) {
                res.success = false;
                std::stringstream ss;
                ss << "Error: Joint '" << joint_name << "' target position " << std::fixed << std::setprecision(4) << target_position 
                   << " rad is out of range [" << lower << ", " << upper << "] rad.";
                res.message = ss.str();
                ROS_ERROR("JointController: %s", res.message.c_str());
                return true;
            }
        }

        // 모든 검사를 통과하면 JointState 메시지 생성 및 발행
        sensor_msgs::JointState joint_state_msg;
        joint_state_msg.header.stamp = ros::Time::now();
        joint_state_msg.name = req.joint_names;
        joint_state_msg.position = req.joint_positions;
        
        joint_pub_.publish(joint_state_msg);
        ROS_INFO("JointController: Published joint command to /foward_joint_states.");

        res.success = true;
        res.message = "Joints command sent successfully and within limits.";
        return true;
    }

private:
    ros::NodeHandle nh_;
    ros::Publisher joint_pub_;
    ros::ServiceServer move_joints_service_;
};

int main(int argc, char **argv)
{
    ros::init(argc, argv, "joint_control_node"); 
    JointController controller;
    ros::spin();
    return 0;
}