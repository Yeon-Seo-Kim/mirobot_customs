#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/PoseStamped.h>
#include <tf/transform_datatypes.h>

#include <cmath>
#include <iostream>
#include <vector>

#include <Eigen/Dense>

class PositionMonitor
{
public:
    ros::NodeHandle nh_;
    PositionMonitor(){
        pose_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/end_effector_pose",10);
        joint_state_sub_ = nh_.subscribe("/joint_states",10,&PositionMonitor::jointStateCallBack,this);
    }
    void jointStateCallBack(const sensor_msgs::JointStateConstPtr& msg)
    {
        std::vector<double> joints = msg->position;
        Eigen::Matrix4d T = calculateTransformMatrix(joints[0],joints[1],joints[2],
                                                    joints[3],joints[4],joints[5]);
        std::vector<double> xyzrpy = calculateXYZRPY(T);
        geometry_msgs::PoseStamped jointpose;
        jointpose.header.stamp = ros::Time::now();
        jointpose.header.frame_id = "base_link";
        jointpose.pose.position.x = xyzrpy[0];
        jointpose.pose.position.y = xyzrpy[1];
        jointpose.pose.position.z = xyzrpy[2];
        
        tf::Quaternion q;
        q.setRPY(xyzrpy[3],xyzrpy[4],xyzrpy[5]);
        jointpose.pose.orientation.x = q.x();
        jointpose.pose.orientation.y = q.y();
        jointpose.pose.orientation.z = q.z();
        jointpose.pose.orientation.w = q.w();
        pose_pub_.publish(jointpose);

    }
    Eigen::Matrix4d calculateTransformMatrix(
        double theta1, double theta2, double theta3,
        double theta4, double theta5, double theta6)
    {
        Eigen::Matrix4d T1,T2,T3,T4,T5,T6;
        T1 << cos(theta1), -sin(theta1),        0,         0,
              sin(theta1),  cos(theta1),        0,         0,
                        0,            0,        1,  0.065406,
                        0,            0,        0,         1;

        T2 << sin(theta2),  cos(theta2),        0,  0.029687,
                        0,            0,        1,    -0.022,
              cos(theta2), -sin(theta2),        0,  0.061593,
                        0,            0,        0,         1;

        T3 << cos(theta3), -sin(theta3),        0,     0.108,
              sin(theta3),  cos(theta3),        0,         0,
                        0,            0,        1,-0.0094471,
                        0,            0,        0,         1;

        T4 << cos(theta4), -sin(theta4),        0,  0.020001,
                        0,            0,        1,   0.10743,
             -sin(theta4), -cos(theta4),        0,  0.031439,
                        0,            0,        0,         1;

        T5 << sin(theta5),  cos(theta5),        0,         0,
                        0,            0,        1, -0.010414,
              cos(theta5), -sin(theta5),        0,   0.06155,
                        0,            0,        0,         1;

        T6 << cos(theta6), -sin(theta6),        0,         0,
                        0,            1,        0,  -0.01628,
            -sin(theta6),  -cos(theta6),        0,  0.010525,
                        0,            0,        0,         1;
                        
        return T1*T2*T3*T4*T5*T6;
    }
    
    std::vector<double> calculateXYZRPY(const Eigen::Matrix4d& T)
    {
        double x = T(0,3);
        double y = T(1,3);
        double z = T(2,3);
        // Eigen::Matrix3d에서 tf::Matrix3x3으로 변환
        Eigen::Matrix3d R = T.block<3, 3>(0, 0);
        tf::Matrix3x3 tf_R(
            R(0,0), R(0,1), R(0,2),
            R(1,0), R(1,1), R(1,2),
            R(2,0), R(2,1), R(2,2));
        // RPY 값 추출
        double roll, pitch, yaw;
        tf_R.getRPY(roll, pitch, yaw); // 이 함수가 직접 계산하는 것보다 안정적입니다.
        return {x, y, z, roll, pitch, yaw};
    }

private:
    ros::Publisher pose_pub_;
    ros::Subscriber joint_state_sub_;
    
};

int main(int argc,char** argv){
    ros::init(argc, argv, "position_monitor_node"); // 노드 이름 지정
    PositionMonitor monitor; // 객체 생성
    ros::spin(); // 콜백 대기
    return 0;
}