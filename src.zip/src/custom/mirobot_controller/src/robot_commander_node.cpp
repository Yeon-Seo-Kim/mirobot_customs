#include "ros/ros.h"
#include "sensor_msgs/JointState.h"

// 새로 생성한 서비스의 헤더 파일 임포트 (패키지이름/서비스파일명.h)
#include "mirobot_controller/MoveJoints.h" 

#include <string>
#include <vector>
#include <map>
#include <utility> // For std::pair
#include <sstream> // For std::stringstream
#include <iomanip> // For std::fixed, std::setprecision

class RobotCommander {
public:
    RobotCommander() : nh_("~") { // 노드 핸들을 private namespace로 초기화
        // /joint_states 토픽 퍼블리셔 초기화
        // 이 퍼블리셔가 mirobot_urdf_2 패키지의 mirobot_write_node가 구독하는 /joint_states 토픽으로 메시지를 보냅니다.
        joint_pub_ = nh_.advertise<sensor_msgs::JointState>("/joint_states", 10);
        ROS_INFO("RobotCommander: /joint_states publisher initialized.");

        // 서비스 서버 초기화: "move_joints"라는 이름의 서비스를 광고
        // 이 서비스는 이 노드의 private namespace에 생성됩니다.
        // (예: /robot_commander_node/move_joints)
        move_joints_service_ = nh_.advertiseService("move_joints", &RobotCommander::handleMoveJoints, this);
        ROS_INFO("RobotCommander: MoveJoints Service Ready at '%s/move_joints'.", nh_.getNamespace().c_str());

        // 필요하다면 여기서 로봇 초기 자세를 설정하는 로직을 추가할 수 있습니다.
        // 예를 들어, 서비스가 시작될 때 로봇을 특정 자세로 옮기는 호출을 할 수도 있습니다.
        // setInitialPose(); 
    }

    // 서비스 콜백 함수 정의
    bool handleMoveJoints(mirobot_controller::MoveJoints::Request &req,
                          mirobot_controller::MoveJoints::Response &res)
    {
        ROS_INFO("Received MoveJoints request for %zu joints.", req.joint_names.size());

        // 요청 유효성 검사 (관절 이름과 위치 배열의 길이가 같은지 확인)
        if (req.joint_names.size() != req.joint_positions.size()) {
            res.success = false;
            res.message = "Error: Mismatch in joint_names and joint_positions array lengths.";
            ROS_ERROR("%s", res.message.c_str());
            return true; 
        }

        // URDF에서 정의된 관절 가동 범위 (라디안)
        // !!! 이 부분은 당신의 로봇 URDF에서 분석한 정확한 값으로 채워 넣으세요 !!!
        std::map<std::string, std::pair<double, double>> current_joint_limits = {
            {"joint1", {-1.7453, 2.7925}},
            {"joint2", {-0.5235, 1.2217}},
            {"joint3", {-2.9671, 1.0472}},
            {"joint4", {-6.1086, 6.1086}},
            {"joint5", {-3.5779, 0.6283}},
            {"joint6", {-6.2832, 6.2832}},
        };

        // 요청된 각 관절의 위치가 가동 범위를 벗어나는지 검사
        for (size_t i = 0; i < req.joint_names.size(); ++i) {
            std::string joint_name = req.joint_names[i];
            double target_position = req.joint_positions[i];

            if (current_joint_limits.find(joint_name) == current_joint_limits.end()) {
                res.success = false;
                res.message = "Error: Unknown joint name '" + joint_name + "'.";
                ROS_ERROR("%s", res.message.c_str());
                return true;
            }

            double lower = current_joint_limits[joint_name].first;
            double upper = current_joint_limits[joint_name].second;

            if (target_position < lower || target_position > upper) {
                res.success = false;
                std::stringstream ss;
                ss << "Error: Joint '" << joint_name << "' target position " << std::fixed << std::setprecision(4) << target_position 
                   << " rad is out of range [" << lower << ", " << upper << "] rad.";
                res.message = ss.str();
                ROS_ERROR("%s", res.message.c_str());
                return true;
            }
        }

        // 모든 검사를 통과하면 JointState 메시지 생성 및 발행
        sensor_msgs::JointState joint_state_msg;
        joint_state_msg.header.stamp = ros::Time::now();
        joint_state_msg.name = req.joint_names;
        joint_state_msg.position = req.joint_positions;
        // velocity, effort 필드를 비워두거나 필요에 따라 추가할 수 있습니다.

        joint_pub_.publish(joint_state_msg); // 퍼블리셔를 통해 JointState 메시지 발행
        ROS_INFO("Published joint command to /joint_states.");

        res.success = true;
        res.message = "Joints command sent successfully and within limits.";
        return true; // 성공적으로 콜백 처리했음을 의미
    }

private:
    ros::NodeHandle nh_; // 노드 핸들
    ros::Publisher joint_pub_; // JointState 메시지 퍼블리셔
    ros::ServiceServer move_joints_service_; // 서비스 서버 객체
};

int main(int argc, char **argv)
{
    // ROS 노드 초기화. 노드 이름은 "robot_commander_node"
    ros::init(argc, argv, "robot_commander_node"); 

    RobotCommander commander; // 컨트롤러 객체 생성

    ros::spin(); // 노드가 서비스 요청을 기다리고 콜백을 처리하도록 함

    return 0;
}