#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <geometry_msgs/PoseStamped.h>

// TF2 includes for pose conversions
#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_eigen/tf2_eigen.h> // For converting geometry_msgs::Pose to Eigen::Isometry3d

// Eigen for matrix and vector operations
#include <Eigen/Dense>
#include <Eigen/SVD> // For pseudo-inverse (JacobiSVD)

// Define robot link lengths and constant offsets based on the provided T matrices
// These are inferred from the constant values in your homogeneous transformation matrices.
// Please verify these values against your robot's actual dimensions.
const double L1_OFFSET_Z = 0.065406;
const double L2_OFFSET_X = 0.029687;
const double L2_OFFSET_Z = -0.022;
const double L3_OFFSET_X = 0.108;
const double L3_OFFSET_Z = -0.0094471;
const double L4_OFFSET_X = 0.020001;
const double L4_OFFSET_Z = 0.10743;
const double L5_OFFSET_Z = -0.010414;
const double L6_OFFSET_Z = -0.01628;

/**
 * @brief Calculates the forward kinematics of the 6-DOF manipulator.
 * @param q A 6-element Eigen::VectorXd containing the joint angles (q0 to q5).
 * @return A 4x4 Eigen::Matrix4d representing the end-effector's homogeneous transformation from the base frame.
 */
Eigen::Matrix4d forwardKinematics(const Eigen::VectorXd& q) {
    if (q.size() != 6) {
        ROS_ERROR("Joint angle vector must be of size 6 for FK.");
        return Eigen::Matrix4d::Identity();
    }

    // Cosine and Sine values for each joint angle
    double c0 = cos(q(0)), s0 = sin(q(0));
    double c1 = cos(q(1)), s1 = sin(q(1));
    double c2 = cos(q(2)), s2 = sin(q(2));
    double c3 = cos(q(3)), s3 = sin(q(3));
    double c4 = cos(q(4)), s4 = sin(q(4));
    double c5 = cos(q(5)), s5 = sin(q(5));

    // T1: Rotation around Z (theta0), Translation along Z
    // C(theta), -S(theta),0,0
    // S(theta), C(theta),0,0
    // 0,0,1,0.065406
    // 0,0,0,1
    Eigen::Matrix4d T1;
    T1 << c0, -s0, 0, 0,
          s0, c0, 0, 0,
          0, 0, 1, L1_OFFSET_Z,
          0, 0, 0, 1;

    // T2: Rotation around X (or Z, check carefully), Translation along X, Translation along Z
    // C(theta),0,-S(theta),0.029687*C(theta)
    // S(theta),0,C(theta),0.029687*S(theta)
    // 0,-1,0,-0.022
    // 0,0,0,1
    // Note: This T2 implies a rotation around Y-axis (or -Y) from previous frame perspective
    // followed by a rotation. The original matrix provided looks like (Rx * Rz) or similar combination.
    // For Jacobian calculation, we assume the rotation axis is the z-axis of the *previous* frame for a revolute joint.
    // Based on the '0, -1, 0' in the third row, it implies a 90 degree rotation around X-axis.
    // Let's stick to the interpretation from the structure provided directly.
    Eigen::Matrix4d T2;
    T2 << c1, 0, -s1, L2_OFFSET_X * c1,
          s1, 0, c1, L2_OFFSET_X * s1,
          0, -1, 0, L2_OFFSET_Z,
          0, 0, 0, 1;

    // T3: Rotation around Z, Translation along X, Translation along Z
    // C(theta),-S(theta),0,0.108*C(theta)
    // S(theta),C(theta),0,0.108*S(theta)
    // 0,0,1,-0.0094471
    // 0,0,0,1
    Eigen::Matrix4d T3;
    T3 << c2, -s2, 0, L3_OFFSET_X * c2,
          s2, c2, 0, L3_OFFSET_X * s2,
          0, 0, 1, L3_OFFSET_Z,
          0, 0, 0, 1;

    // T4: Similar to T2's structure
    // C(theta),0,-S(theta),0.020001*C(theta)
    // S(theta),0,C(theta),0.020001*S(theta)
    // 0,-1,0,0.10743
    // 0,0,0,1
    Eigen::Matrix4d T4;
    T4 << c3, 0, -s3, L4_OFFSET_X * c3,
          s3, 0, c3, L4_OFFSET_X * s3,
          0, -1, 0, L4_OFFSET_Z,
          0, 0, 0, 1;

    // T5: Rotation around Z (or Y depending on perspective)
    // C(theta),0,S(theta),0
    // S(theta),0,-C(theta),0
    // 0,1,0,-0.010414
    // 0,0,0,1
    Eigen::Matrix4d T5;
    T5 << c4, 0, s4, 0,
          s4, 0, -c4, 0,
          0, 1, 0, L5_OFFSET_Z,
          0, 0, 0, 1;

    // T6: Similar to T2/T4 structure
    // C(theta),0,-S(theta),0
    // S(theta),0,C(theta),0
    // 0,-1,0,-0.01628
    // 0,0,0,1
    Eigen::Matrix4d T6;
    T6 << c5, 0, -s5, 0,
          s5, 0, c5, 0,
          0, -1, 0, L6_OFFSET_Z,
          0, 0, 0, 1;

    // Chain transformations
    return T1 * T2 * T3 * T4 * T5 * T6;
}

/**
 * @brief Calculates the geometric Jacobian matrix for the 6-DOF manipulator.
 * @param q A 6-element Eigen::VectorXd containing the current joint angles.
 * @return A 6x6 Eigen::MatrixXd representing the Jacobian.
 */
Eigen::MatrixXd calculateJacobian(const Eigen::VectorXd& q) {
    Eigen::MatrixXd J(6, 6);

    // Calculate transformation matrices to each joint frame from the base frame
    Eigen::Matrix4d T0_1, T0_2, T0_3, T0_4, T0_5, T0_6;

    // Cosine and Sine values for each joint angle
    double c0 = cos(q(0)), s0 = sin(q(0));
    double c1 = cos(q(1)), s1 = sin(q(1));
    double c2 = cos(q(2)), s2 = sin(q(2));
    double c3 = cos(q(3)), s3 = sin(q(3));
    double c4 = cos(q(4)), s4 = sin(q(4));
    double c5 = cos(q(5)), s5 = sin(q(5));

    // Calculate individual joint transformation matrices
    Eigen::Matrix4d Ti[6]; // Array to store T1 to T6

    Ti[0] << c0, -s0, 0, 0, s0, c0, 0, 0, 0, 0, 1, L1_OFFSET_Z, 0, 0, 0, 1;
    Ti[1] << c1, 0, -s1, L2_OFFSET_X * c1, s1, 0, c1, L2_OFFSET_X * s1, 0, -1, 0, L2_OFFSET_Z, 0, 0, 0, 1;
    Ti[2] << c2, -s2, 0, L3_OFFSET_X * c2, s2, c2, 0, L3_OFFSET_X * s2, 0, 0, 1, L3_OFFSET_Z, 0, 0, 0, 1;
    Ti[3] << c3, 0, -s3, L4_OFFSET_X * c3, s3, 0, c3, L4_OFFSET_X * s3, 0, -1, 0, L4_OFFSET_Z, 0, 0, 0, 1;
    Ti[4] << c4, 0, s4, 0, s4, 0, -c4, 0, 0, 1, 0, L5_OFFSET_Z, 0, 0, 0, 1;
    Ti[5] << c5, 0, -s5, 0, s5, 0, c5, 0, 0, -1, 0, L6_OFFSET_Z, 0, 0, 0, 1;

    // Calculate transformations from base frame to each joint frame (T0_i)
    std::vector<Eigen::Matrix4d> T0_i(7); // T0_0 to T0_6
    T0_i[0] = Eigen::Matrix4d::Identity(); // T0_0 is identity

    for (int i = 0; i < 6; ++i) {
        T0_i[i+1] = T0_i[i] * Ti[i];
    }

    Eigen::Vector3d p_end = T0_i[6].block<3, 1>(0, 3); // End-effector position (p6 in base frame)

    // Fill the Jacobian columns
    // For a revolute joint: J_i = [z_{i-1} x (p_end - p_{i-1}); z_{i-1}]
    for (int i = 0; i < 6; ++i) {
        Eigen::Vector3d z_i_minus_1 = T0_i[i].block<3, 1>(0, 2); // Z-axis of previous frame in base coords
        Eigen::Vector3d p_i_minus_1 = T0_i[i].block<3, 1>(0, 3); // Origin of previous frame in base coords

        J.col(i).head<3>() = z_i_minus_1.cross(p_end - p_i_minus_1); // Linear velocity component
        J.col(i).tail<3>() = z_i_minus_1;                               // Angular velocity component
    }

    return J;
}

/**
 * @brief Calculates the pose error between current and desired end-effector poses.
 * @param T_current Current end-effector pose (4x4 homogeneous transformation matrix).
 * @param T_desired Desired end-effector pose (4x4 homogeneous transformation matrix).
 * @return A 6-element Eigen::VectorXd containing the [linear_error; angular_error].
 */
Eigen::VectorXd calculatePoseError(const Eigen::Matrix4d& T_current, const Eigen::Matrix4d& T_desired) {
    Eigen::VectorXd error(6);

    // Linear error (position error)
    error.head<3>() = T_desired.block<3, 1>(0, 3) - T_current.block<3, 1>(0, 3);

    // Angular error (orientation error) using axis-angle representation
    // R_error = R_current^T * R_desired
    Eigen::Matrix3d R_current = T_current.block<3, 3>(0, 0);
    Eigen::Matrix3d R_desired = T_desired.block<3, 3>(0, 0);
    Eigen::Matrix3d R_error = R_current.transpose() * R_desired;

    // Convert error rotation matrix to axis-angle representation
    Eigen::AngleAxisd aa(R_error);
    error.tail<3>() = aa.axis() * aa.angle(); // Angular error vector

    return error;
}

/**
 * @brief Calculates the damped pseudo-inverse of a matrix using SVD.
 * @param J Input matrix (Jacobian).
 * @param lambda Damping factor.
 * @return The damped pseudo-inverse of J.
 */
Eigen::MatrixXd dampedPseudoInverse(const Eigen::MatrixXd& J, double lambda) {
    Eigen::JacobiSVD<Eigen::MatrixXd> svd(J, Eigen::ComputeThinU | Eigen::ComputeThinV);
    Eigen::VectorXd s = svd.singularValues();

    // Compute damped singular values for pseudo-inverse
    // s_inv_damped_i = s_i / (s_i^2 + lambda^2)
    Eigen::VectorXd s_inv_damped = s.array() / (s.array().square() + lambda * lambda);

    return svd.matrixV() * s_inv_damped.asDiagonal() * svd.matrixU().transpose();
}

/**
 * @brief ROS Node class for the Inverse Kinematics Solver.
 */
class IKSolverNode {
public:
    /**
     * @brief Constructor for IKSolverNode.
     */
    IKSolverNode() : nh_("~"), tf_buffer_(), tf_listener_(tf_buffer_) {
        // ROS Publishers and Subscribers
        joint_state_pub_ = nh_.advertise<sensor_msgs::JointState>("/inverse_joint_states", 1);
        target_pose_sub_ = nh_.subscribe("/target_pose", 1, &IKSolverNode::targetPoseCallback, this);

        // Initialize current joint angles (home position or safe starting configuration)
        current_joint_angles_.resize(6);
        current_joint_angles_ << 0.0, 0.0, 0.0, 0.0, 0.0, 0.0; 

        // Node parameters (can be loaded from ROS parameter server)
        nh_.param<int>("max_iterations", max_iterations_, 500);
        nh_.param<double>("position_tolerance", tolerance_, 1e-4); // meters
        nh_.param<double>("angular_tolerance", angular_tolerance_, 1e-3); // radians
        nh_.param<double>("step_size", step_size_, 0.1); // Learning rate for IK iterations
        nh_.param<double>("damping_lambda", damping_lambda_, 0.01); // Damping factor for DLS

        ROS_INFO("IK Solver Node Initialized.");
        ROS_INFO("Max Iterations: %d", max_iterations_);
        ROS_INFO("Position Tolerance: %.5f m", tolerance_);
        ROS_INFO("Angular Tolerance: %.5f rad", angular_tolerance_);
        ROS_INFO("Step Size: %.2f", step_size_);
        ROS_INFO("Damping Lambda: %.3f", damping_lambda_);
    }

    /**
     * @brief Callback for receiving target pose messages.
     * @param msg A pointer to the received geometry_msgs::PoseStamped message.
     */
    void targetPoseCallback(const geometry_msgs::PoseStamped::ConstPtr& msg) {
        ROS_INFO_STREAM("Received new target pose: [" 
                        << msg->pose.position.x << ", " 
                        << msg->pose.position.y << ", " 
                        << msg->pose.position.z << "]");

        // Convert ROS PoseStamped message to Eigen::Isometry3d using tf2_eigen
        Eigen::Isometry3d target_pose_isometry;
        tf2::fromMsg(msg->pose, target_pose_isometry);
        
        // Convert Eigen::Isometry3d to a 4x4 homogeneous matrix for FK/IK calculations
        Eigen::Matrix4d T_desired = Eigen::Matrix4d::Identity();
        T_desired.block<3,3>(0,0) = target_pose_isometry.rotation();
        T_desired.block<3,1>(0,3) = target_pose_isometry.translation();

        // Solve Inverse Kinematics
        Eigen::VectorXd solved_angles = solveIK(T_desired, current_joint_angles_);

        // Update current angles to the solved angles for the next IK call
        // This makes the IK more stable if target poses change incrementally.
        current_joint_angles_ = solved_angles;

        // Publish the solved joint angles
        publishJointStates(solved_angles);
    }

    /**
     * @brief Solves the Inverse Kinematics problem for a given target pose.
     * @param T_desired The desired end-effector pose (4x4 homogeneous matrix).
     * @param initial_q The initial guess for joint angles (6-element vector).
     * @return The calculated joint angles (6-element vector).
     */
    Eigen::VectorXd solveIK(const Eigen::Matrix4d& T_desired, const Eigen::VectorXd& initial_q) {
        Eigen::VectorXd q_current = initial_q;
        
        for (int i = 0; i < max_iterations_; ++i) {
            // 1. Calculate current end-effector pose using FK
            Eigen::Matrix4d T_current = forwardKinematics(q_current);

            // 2. Calculate pose error
            Eigen::VectorXd pose_error = calculatePoseError(T_current, T_desired);

            // 3. Check for convergence
            if (pose_error.head<3>().norm() < tolerance_ && pose_error.tail<3>().norm() < angular_tolerance_) {
                ROS_INFO("IK converged in %d iterations. Final error: Pos=%.6f, Ang=%.6f", 
                         i, pose_error.head<3>().norm(), pose_error.tail<3>().norm());
                return q_current;
            }

            // 4. Calculate Jacobian matrix
            Eigen::MatrixXd J = calculateJacobian(q_current);
            
            // Check for NaNs or Infs in Jacobian (can happen near singularities or with bad parameters)
            if (!J.allFinite()) {
                ROS_WARN("Jacobian contains non-finite values. Aborting IK solve.");
                break; // Exit loop if Jacobian is bad
            }

            // 5. Calculate Damped Pseudo-Inverse of Jacobian
            Eigen::MatrixXd J_plus = dampedPseudoInverse(J, damping_lambda_);

            // 6. Calculate joint angle change (delta_q)
            Eigen::VectorXd delta_q = J_plus * pose_error;

            // 7. Update joint angles
            q_current += step_size_ * delta_q;

            // Optional: Clamp joint angles to their physical limits
            // This is crucial for real robots to prevent out-of-range movements.
            // Example for joint 0 (assuming limits -M_PI to M_PI):
            // if (q_current(0) > M_PI) q_current(0) = M_PI;
            // if (q_current(0) < -M_PI) q_current(0) = -M_PI;
            // Apply similar logic for all 6 joints.
        }

        // If IK did not converge
        Eigen::VectorXd final_error = calculatePoseError(forwardKinematics(q_current), T_desired);
        ROS_WARN("IK did not converge after %d iterations. Final error: Pos=%.6f, Ang=%.6f", 
                 max_iterations_, final_error.head<3>().norm(), final_error.tail<3>().norm());
        
        return q_current; // Return the best estimate
    }

    /**
     * @brief Publishes the calculated joint angles to the /joint_states topic.
     * @param q_solved The solved joint angles.
     */
    void publishJointStates(const Eigen::VectorXd& q_solved) {
        sensor_msgs::JointState js;
        js.header.stamp = ros::Time::now();
        js.name = {"joint1", "joint2", "joint3", "joint4", "joint5", "joint6"}; // Replace with your actual URDF joint names
        js.position.resize(6);
        for (int i = 0; i < 6; ++i) {
            js.position[i] = q_solved(i);
        }
        joint_state_pub_.publish(js);
        ROS_INFO("Published new joint states.");
    }

    /**
     * @brief Main loop for the ROS node.
     */
    void run() {
        ros::spin(); // Spin forever, handling callbacks
    }

private:
    ros::NodeHandle nh_;
    ros::Publisher joint_state_pub_;
    ros::Subscriber target_pose_sub_;
    
    tf2_ros::Buffer tf_buffer_;            // TF2 Buffer to store transforms
    tf2_ros::TransformListener tf_listener_; // TF2 Listener to populate the buffer

    Eigen::Isometry3d target_pose_eigen_; // Target pose as Eigen Isometry3d
    Eigen::VectorXd current_joint_angles_; // Stores the current joint angles (used as initial guess for next IK)

    // Parameters for IK solver
    int max_iterations_;
    double tolerance_;
    double angular_tolerance_;
    double step_size_;
    double damping_lambda_;
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "ik_solver_node");
    IKSolverNode solver;
    solver.run();
    return 0;
}